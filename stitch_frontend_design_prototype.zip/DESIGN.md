---
name: Audit Paper Desk
colors:
  surface: '#f9faf7'
  surface-dim: '#d9dad7'
  surface-bright: '#f9faf7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f1'
  surface-container: '#edeeeb'
  surface-container-high: '#e7e8e6'
  surface-container-highest: '#e2e3e0'
  on-surface: '#191c1b'
  on-surface-variant: '#444845'
  inverse-surface: '#2e312f'
  inverse-on-surface: '#f0f1ee'
  outline: '#747874'
  outline-variant: '#c4c7c3'
  surface-tint: '#5a605c'
  primary: '#020503'
  on-primary: '#ffffff'
  primary-container: '#1a1f1c'
  on-primary-container: '#828783'
  inverse-primary: '#c3c8c3'
  secondary: '#5a605b'
  on-secondary: '#ffffff'
  secondary-container: '#dfe4de'
  on-secondary-container: '#606661'
  tertiary: '#000503'
  on-tertiary: '#ffffff'
  tertiary-container: '#002318'
  on-tertiary-container: '#009871'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe4de'
  primary-fixed-dim: '#c3c8c3'
  on-primary-fixed: '#181d1a'
  on-primary-fixed-variant: '#434844'
  secondary-fixed: '#dfe4de'
  secondary-fixed-dim: '#c3c8c2'
  on-secondary-fixed: '#181d19'
  on-secondary-fixed-variant: '#434844'
  tertiary-fixed: '#71fac8'
  tertiary-fixed-dim: '#50ddad'
  on-tertiary-fixed: '#002116'
  on-tertiary-fixed-variant: '#00513b'
  background: '#f9faf7'
  on-background: '#191c1b'
  surface-variant: '#e2e3e0'
  paper-base: '#F6F7F4'
  paper-elevated: '#FBFCF9'
  ink: '#1A1F1C'
  ink-secondary: '#1A1F1CB3'
  ink-muted: '#1A1F1C99'
  ink-meta: '#1A1F1C80'
  ink-disabled: '#1A1F1C4D'
  rule: '#D5DAD4'
  chip-fill: '#E8EBE6'
  mint-gate: '#00B386'
  amber-hold: '#C47A12'
  vermillion-flag: '#C23A2B'
  canvas-white: '#FFFFFF'
typography:
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  wordmark:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  letter-body:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 27px
  letter-body-recap:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-default:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-secondary:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 19px
  label-default:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-compact:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  telemetry-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-desktop: 0.75rem
  margin: 1.5rem
  margin-workbench: 1.5rem
  space-2xs: 0.25rem
  space-xs: 0.375rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 5.5rem
  space-4xl: 6rem
---

## Brand & Style

This design system establishes an audit-grade, high-integrity operations console engineered exclusively for investment compliance and customer support agents. Moving deliberately away from consumer fintech tropes, saturated SaaS dashboards, card farms, and conversational AI bubbles, the interface operates under a tactile **Paper and Ink Minimalism** philosophy.

The emotional signature is unhurried, exact, calm, and legally binding. Visual weight mimics physical printed financial instruments—specifically crisp physical statements and broker correspondence—relying on high-contrast text, deliberate hairline grid structures, and absolute planar flatness. Surfaces never use drop shadows, blurred glass, or decorative gradients. Visual cues function as legal evidence: content is dense and left-aligned, typography strictly delineates between human draft copy and machine telemetry, and interactive levers remain stark and binary.

## Colors

The palette enforces strict chromatic restraint based on print materiality. Dark mode is categorically unsupported; the interface exists solely as a printed light sheet.

### Color Hierarchy & Roles
- **Paper Canvas (`#F6F7F4`)**: The global page background. A cool, grey-green substrate that relieves optical fatigue while mirroring physical bond paper.
- **Elevated Paper (`#FBFCF9`)**: Reserved strictly for the 62% customer reply letter panel, distinguishing outgoing correspondence from the administrative chassis.
- **Ink (`#1A1F1C`)**: The primary typographic and architectural color. Used for structural 1px container frames, headers, body copy, and primary navigation elements. Opacity tiers govern visual secondary hierarchy without introducing disconnected color tones (`70%` for intake subheads, `60%` for P3 priority text, `50%` for system notices, and `30%` for disabled inputs).
- **Rule (`#D5DAD4`)**: Universal 1px hairline boundary for table divisions, timeline tracks, and subtle perimeter separation.
- **Chip Fill (`#E8EBE6`)**: Low-contrast neutral fill reserved exclusively for redaction and PII tokens (e.g., `[PAN]`, `[PHONE]`).

### Strict Functional Chroma
Accent colors are strictly semantic state gates and must never appear as decorative washes, backgrounds, or status pills:
- **Mint Gate (`#00B386`)**: Restricted solely to verified conditions—Reviewer `PASS` verdicts, 6px agent completion markers, and the definitive `Approve` execution action. Mint is never used for general "success" messages or branding flourishes.
- **Amber Hold (`#C47A12`)**: Signifies blocking procedural divergence, specifically `HOLD_DISAGREEMENT` rules and `P2` priority tags. Applied as 1px horizontal top/bottom rules and status typography.
- **Vermillion Flag (`#C23A2B`)**: Deployed exclusively for audit rejection, reviewer `FAIL` states, `P1` priority tags, and terminal `Discard` actions.

## Typography

The typographical structure enforces a strict division of voice across three specialized type families:

1. **System & Operational Chrome (`IBM Plex Sans`)**: Provides unambiguous technical clarity across navigation, workbench titles, triage gates, buttons, and system form fields.
2. **Customer Letter Surface (`Source Serif 4`)**: Applied exclusively to the reply draft inside the left letter panel. Sized at 18px regular with 1.5 line height and an enforced maximum reading line length of 62 characters, it reproduces the gravitas and legibility of an editorial letter or legal response.
3. **Machine Telemetry & Identification (`JetBrains Mono` / `IBM Plex Mono`)**: Assigned to all non-human artifacts: transaction IDs, session hashes, timestamps, agent latency counters, and telemetry axes.

### Prohibitions
- All-caps eyebrow text and middle-dot (`·`) metadata separators are strictly banned. Use low-contrast vertical pipes (`|`) or fixed whitespace for spatial separation.
- Never render telemetry data in proportional fonts or the customer draft in sans-serif.

## Layout & Spacing

The layout is built for high-throughput 1440px desktop displays, left-aligned, eliminating auto-centering margins on data tables and workbenches.

### Workbench Split Ratio
The core console workbench adopts an asymmetric two-column split:
- **Left Column (62% width)**: Primary editorial space. Hosts the source customer complaint and the live `Source Serif 4` draft letter panel.
- **Right Column (38% width)**: Procedural control gate. Houses routing controls, multi-lane agent trace diagnostics, compliance review metrics, and terminal approval triggers.
- **Gutter**: Fixed at 12px (`0.75rem`), maintaining dense structural cohesion without visual float.

### Fixed Layout Benchmarks
- **Top Intake Form Offset**: `96px` top margin beneath the universal persistent header.
- **Intake Center Column**: `720px` fixed width when in initial standalone intake view.
- **Refinement Drawer**: `520px` fixed width, anchoring directly to the right viewport perimeter.
- **Post-Approval Recap**: `640px` fixed reading column.
- **Draft Letter Panel Internal Inset**: Rigid `32px` (`2rem`) padding to mimic statement borders.

### Telemetry Agent Track Layout
The telemetry lane presents three horizontal lanes (Facts | Pattern | Compliance):
- Fixed active running height: `160px`.
- Fixed resolved review height: `88px`.
- All three lanes lock their execution start markers to a single synchronized vertical axis at `t=0.0s`.

### Responsive Adaptation
- **Desktop (1440px and above)**: Full asymmetric 62/38 side-by-side workbench.
- **Tablet / Reduced Desktop (1024px)**: Columns collapse into an ordered vertical stack: customer draft letter occupies the upper tier, gate controls flow immediately below. Type sizes remain invariant.

## Elevation & Depth

This system operates without simulated physical lighting, elevation blurs, or ambient drop shadows. All interface depth is achieved through **structural containment, planar layering, and hairline rules**.

### Spatial Layer Model
- **Substrate (Layer 0)**: The global page surface in Paper Base (`#F6F7F4`).
- **Work Surface (Layer 1)**: Elevated Paper (`#FBFCF9`) bounded by a 1px solid Ink (`#1A1F1C`) or Hairline (`#D5DAD4`) perimeter. Panels do not lift off the page; they sit flush like adjoining print sheets.
- **Slide-Over Refine Sheet (Layer 2)**: Anchored to the right viewport border (`520px` width) with a 1px solid Ink left edge. It casts zero box-shadow over Layer 1 and does not engage backdrop blurs or dimming overlays. The underlying UI remains sharp and readable beneath the panel.

### Rules & State Dividers
- Hairlines are rendered strictly at 1px using `#D5DAD4`.
- Critical audit states are punctuated using 1px top and bottom rules across standard panel boundaries:
  - Amber warning banners: `1px solid #C47A12` top and bottom borders.
  - Rejection / Reviewer Fail states: `1px solid #C23A2B` top and bottom borders.

## Shapes

The geometric personality balances industrial angularity with subtle, functional corner rounding. Corner radii are systematically partitioned according to the permanence of the element:

### Sharp Geometry (`0px`)
Structural framing surfaces, data wrappers, and state markers must remain pure rectangles:
- Draft reply letter container
- Reviewer gate container and status headers
- Refine sliding panel
- Priority flags (`P1`, `P2`, `P3`)
- 6px × 6px square agent status ticks

### Soft Functional Geometry (`4px`)
Interactive touch targets and micro-redaction chips take a subtle `4px` radius to indicate tactility and modular encapsulation:
- Primary and secondary buttons
- Multiline form inputs (`<textarea>`, `<input>`)
- PII and redaction placeholder chips (`[PAN]`, `[PHONE]`, `[BANK_ACC]`)

## Components

### Buttons
All buttons maintain a strict `40px` height with a `4px` corner radius and no elevation shadows:
- **Primary Gate (`Approve`)**: Solid Mint (`#00B386`) fill with `#FFFFFF` text. This button appears **only** when all review gates yield `PASS`. It is completely omitted from the layout during blocking states, not merely greyed out.
- **Secondary Action (`Refine`)**: `#F6F7F4` or `#FBFCF9` surface with a `1px solid #1A1F1C` border and `#1A1F1C` text.
- **Terminal Rejection (`Discard`)**: Flat text button styled in Vermillion (`#C23A2B`) with no background.
- **Intake Submit**: Solid Ink (`#1A1F1C`) with white text. Disabled state switches fill to `#1A1F1C4D` with no cursor affordance.

### Input Fields & Textareas
- Base background: `#FFFFFF` or `#FBFCF9`.
- Border: `1px solid #1A1F1C` on active/resting states; `1px solid #C23A2B` during validation failures. Minimum textarea height is `220px`.
- Padding: `12px 16px`. Focus state shifts rule thickness to `2px solid #1A1F1C` with zero shadow ring.

### Redaction & PII Chips
- Non-interactive tokens used inside drafting and source extraction areas.
- Background: `#E8EBE6`. Radius: `4px`.
- Font: `JetBrains Mono`, 12px, `#1A1F1C`. Text is enclosed in brackets without internal iconography.

### Status Indicators & Agent Telemetry
- Real-time agent status markers are drawn as precise `6px × 6px` squares (Mint for verified, Amber for recalculating).
- Progress inside the three horizontal agent lanes (Facts, Pattern, Compliance) avoids cyclical spinners or skeleton shimmers. Execution is visualized via a single-pixel horizontal rule advancing smoothly across the time axis from `t=0.0s`.

### Draft Letter Panel
- Background: `#FBFCF9` framed by a `1px solid #D5DAD4` outer border, with `0px` radius and `32px` internal padding.
- Text: Rendered in `Source Serif 4`, 18px regular, 1.5 line height, max width constrained to 62 characters per line.

### Reviewer Gate Panel
- Background: `#F6F7F4` with `0px` radius.
- Contains modular audit sections separated by `1px solid #D5DAD4` rules.
- Verdict tags use monochromatic typography paired with semantic top/bottom 1px rules when escalated.